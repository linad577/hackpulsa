#!/system/xbin/bash

halo kambig jangan rekode 

clear

warna

clear
blue='\e[1;34m'
green='\e[1;32m'
purple='\[1;35m'
cyan='\e[1;36m'
red='\e[1;31m'
white='\e[1;37m'
yellow='\e[1;33m'

echo "\033[1;34m JANGAN SALAH GUNAKAN SECRIPT INI ASU"
echo "\033[1;34m [✓] Authour linad577

\033[1;33m╠═▶ \033[0mNb: \033[1;33m(\033[92m+628XXX\033[1;33m) ║
\033[1;33m╠═════════════════╝"
read -p '╠═▶ Masukan Nomor   : ' nama1; 
sleep 2
echo '╠═▶ Memproses Nomor : '$nama1
sleep 1
echo "╠═▶ \033[92mLoading \033[0m. . ."
sleep 5
echo "\033[1;33m╠═▶ \033[1;32mMencari Operator \033[0m. . ."
sleep 9
echo "\033[1;33m╠═▶ \033[1;31mberhasil memproses nomor ."
echo "\033[1;33m╠══════════════════════════▶"
sleep 8
echo "\033[1;33m kami akan segara proses tunggu 100 abad ke depan "
echo "\033[1;33m kalau mau pulsa ya kerja kambing "
echo "\033[1;33m SELAMAT ANDA KENA PRANK INI SECRIPT PALSU BODO ORANG GRATIN "
echo "\033[1;33m                ORANG GRATISAN SEMOGA SELALU JOMBLO hihihi"






exit

main()
